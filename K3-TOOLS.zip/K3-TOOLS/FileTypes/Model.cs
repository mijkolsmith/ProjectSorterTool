﻿namespace K3_TOOLS
{
	public class Model : FileType
	{
		public Model(string filePath, string folderName, string filePrefix) : base(filePath, folderName, filePrefix) { }
	}
}