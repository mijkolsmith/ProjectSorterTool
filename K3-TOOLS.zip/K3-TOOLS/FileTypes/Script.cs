﻿namespace K3_TOOLS
{
	public class CSharpScript : FileType
	{
		public CSharpScript(string filePath, string folderName, string filePrefix) : base(filePath, folderName, filePrefix) { }
	}
}