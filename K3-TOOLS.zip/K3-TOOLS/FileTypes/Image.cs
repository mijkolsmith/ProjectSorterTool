﻿namespace K3_TOOLS
{
	public class Image : FileType
	{
		public Image(string filePath, string folderName, string filePrefix) : base(filePath, folderName, filePrefix) { }
	}
}