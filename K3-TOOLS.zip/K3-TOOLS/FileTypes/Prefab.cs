﻿namespace K3_TOOLS
{
	public class Prefab : FileType
	{
		public Prefab(string filePath, string folderName, string filePrefix) : base(filePath, folderName, filePrefix) { }
	}
}