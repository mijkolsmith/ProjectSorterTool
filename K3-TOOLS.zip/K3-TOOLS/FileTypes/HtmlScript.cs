﻿namespace K3_TOOLS
{
	public class HtmlScript : FileType
	{
		public HtmlScript(string filePath, string folderName, string filePrefix) : base(filePath, folderName, filePrefix) { }
	}
}