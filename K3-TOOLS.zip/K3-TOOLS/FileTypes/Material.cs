﻿namespace K3_TOOLS
{
	public class Material : FileType
	{
		public Material(string filePath, string folderName, string filePrefix) : base(filePath, folderName, filePrefix) { }
	}
}