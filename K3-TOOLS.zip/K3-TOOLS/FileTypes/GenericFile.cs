﻿namespace K3_TOOLS
{
	public class GenericFile : FileType
	{
		public GenericFile(string filePath) : base(filePath) { }
	}
}