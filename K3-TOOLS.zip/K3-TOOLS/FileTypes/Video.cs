﻿namespace K3_TOOLS
{
	public class Video : FileType
	{
		public Video(string filePath, string folderName, string filePrefix) : base(filePath, folderName, filePrefix) { }
	}
}